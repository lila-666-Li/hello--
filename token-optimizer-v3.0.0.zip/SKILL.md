---
name: token-optimizer-v3
version: 3.0.0
description: "省钱小达人·角色化 Token 优化技能。使用 feishu_ask_user_question 卡片交互，选角色自动匹配模型组合。便宜模型做分类/提取，贵模型只做核心推理。任何模型切换必须使用人确认。Use when the user says 省钱/切换角色/token优化/切换模型/省钱小达人/优化token/省钱技能, or wants to optimize model routing costs by role."
---

# 🔋 省钱小达人 v3.0

基于云文档《按使用人区分的省Token方案》。

## 核心规则

1. **全部使用 `feishu_ask_user_question` 卡片交互**，不用交互式卡片按钮
2. **任何模型切换/修改必须使用人确认**
3. 便宜模型做分类/提取，贵模型只做核心推理
4. 预设可随时自定义修改，也可「恢复预设」

## 可用模型

| 别名 | 完整模型 ID | 上下文 | 输出价 | 定位 |
|------|------------|--------|--------|------|
| M2.7 | router_aliyun/MiniMax-M2.7 | 200K | ¥8.4 | 最便宜 |
| qw3.6p | router_aliyun/qwen3.6-plus | 1M | ¥12 | 日常主力 |
| glm5.1 | router_aliyun/glm-5.1 | 200K | ¥24 | 文本处理 |
| k2.6 | router_aliyun/kimi-k2.6 | 200K | ¥27 | 图文理解 |
| omni | router_aliyun/qwen3.5-omni-plus | 192K | ¥40 | 多模态 |
| qw3.6m | router_aliyun/qwen3.6-max-preview | 224K | ¥54 | 中等推理 |
| codex5.3 | router_ucloud/gpt-5.3-codex | 400K | ¥99.68 | 编码 |
| sonnet | router_ucloud/claude-sonnet-4-6 | 200K | ¥106.8 | 核心推理 |
| opus4.7 | router_ucloud/claude-opus-4-7 | 500K | ¥178 | 深度决策 |
| gpt5.5 | router_ucloud/gpt-5.5 | 200K | ¥213.6 | 最强推理 |

## 角色预设

| 角色 | 日常/分类(便宜) | 核心任务(主力) | 复杂场景(按需) | 日均 |
|------|---------------|---------------|---------------|------|
| A 支撑人员 | qw3.6p | qw3.6p | qw3.6m | ¥0.5-2 |
| B 技术开发 | qw3.6p | codex5.3 | gpt5.5 | ¥3-10 |
| C 管理决策 | qw3.6p | sonnet | opus4.7 | ¥0.2-1 |
| D 业务需求 | qw3.6p | qw3.6p | sonnet | ¥1-3 |

## 交互流程（全部用 feishu_ask_user_question）

### 步骤1：角色选择

用户说触发词时，发送角色选择卡片：

```
feishu_ask_user_question({
  questions: [{
    header: "选择角色",
    multiSelect: false,
    question: "选择你的使用角色，系统将自动匹配最优模型组合",
    options: [
      { label: "A 💼 支撑人员", description: "高频日常对话/数据处理 · qw3.6p+qw3.6m · ¥0.5-2/天" },
      { label: "B 💻 技术开发", description: "代码生成+调试/大上下文 · codex5.3+qw3.6p · ¥3-10/天" },
      { label: "C 📈 管理决策", description: "报告分析/决策 · sonnet+qw3.6p · ¥0.2-1/天" },
      { label: "D 📝 业务需求", description: "话术生成/方案编写 · qw3.6p+sonnet · ¥1-3/天" }
    ]
  }]
})
```

### 步骤2：确认切换

用户选择角色后，发送确认卡片：

```
feishu_ask_user_question({
  questions: [{
    header: "确认切换",
    multiSelect: false,
    question: "确认切换到【X 角色名】？\n\n• 日常/分类 → xxx（¥xx）\n• 核心任务 → xxx（¥xx）\n• 复杂场景 → xxx（¥xx）\n• 日均成本：¥x-x",
    options: [
      { label: "✅ 确认切换", description: "应用角色配置" },
      { label: "❌ 取消", description: "保持当前配置" }
    ]
  }]
})
```

### 步骤3：执行

用户确认后：
1. 用 `session_status` 的 `model` 参数设置默认模型
2. 应用对应策略（记忆精简等）
3. 更新 `state/role-config.json`
4. 发送完成通知

### 自定义修改

用户说「把XX任务换成XX模型」时：
1. 确认要修改的任务类型和新模型
2. 用 `feishu_ask_user_question` 发送确认卡片
3. 确认后更新配置

### 恢复预设

用户说「恢复预设」时，用 `feishu_ask_user_question` 确认后恢复角色默认组合。

## 触发词
省钱 / 切换角色 / token优化 / 切换模型 / 省钱小达人 / 优化token / 省钱技能

## 触发边界
当用户说出上述触发词或表达模型/成本优化意图时激活。激活后首先发送角色选择卡片，等待用户选择并确认后再执行配置变更。不自动执行模型切换，所有变更必须经用户卡片确认。

## 状态文件
`state/role-config.json` 记录角色、模型、自定义覆盖、切换历史。

## 安全红线
- 模型切换/修改必须确认
- 不自动执行
- 不凭猜测修改

## 云文档
完整方案：[按使用人区分的省Token方案](https://www.feishu.cn/docx/RTyFdrJl8oBMQRxb62dcJBJNnYg)
