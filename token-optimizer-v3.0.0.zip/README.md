# 🔋 Token Optimizer · 省钱小达人

基于角色的 Token 优化技能。选择角色后自动匹配预设模型组合，便宜模型做分类/提取，贵模型只做核心推理。

## 特性

- **角色化预设**：4类角色自动匹配最优模型组合
- **确认机制**：任何模型切换必须使用人确认
- **自定义覆盖**：可随时修改任一任务类型的模型搭配
- **恢复预设**：一键回到角色默认配置

## 角色预设

| 角色 | 日常/分类 | 核心任务 | 复杂场景 | 日均 |
|------|----------|---------|---------|------|
| A 支撑人员 | qw3.6p | qw3.6p | qw3.6m | ¥0.5-2 |
| B 技术开发 | qw3.6p | codex5.3 | gpt5.5 | ¥3-10 |
| C 管理决策 | qw3.6p | sonnet | opus4.7 | ¥0.2-1 |
| D 业务需求 | qw3.6p | qw3.6p | sonnet | ¥1-3 |

## 安装

### 方式一：本地安装（推荐）

```bash
# 技能目录已存在，OpenClaw 自动扫描加载
~/.openclaw/workspace/skills/token-optimizer/
```

### 方式二：分享安装

```bash
# 从 ClawHub 安装（待发布）
clawhub install token-optimizer --registry "https://www.clawhub.ai"
```

## 使用方法

| 你说 | 效果 |
|------|------|
| 「省钱」/「切换角色」 | 展示角色选择卡片 |
| 「A/B/C/D」 | 选择角色 → 弹出确认 |
| 「确认」 | 执行模型切换 |
| 「把XX换成XX」 | 自定义修改模型 |
| 「恢复预设」 | 回到角色默认 |
| 「当前状态」 | 查看当前配置 |

## 可用模型

| 别名 | 模型 ID | 输出价格 | 定位 |
|------|--------|---------|------|
| M2.7 | MiniMax-M2.7 | ¥8.4 | 最便宜 |
| qw3.6p | qwen3.6-plus | ¥12 | 日常主力 |
| glm5.1 | glm-5.1 | ¥24 | 文本处理 |
| k2.6 | kimi-k2.6 | ¥27 | 图文理解 |
| omni | qwen3.5-omni-plus | ¥40 | 多模态 |
| qw3.6m | qwen3.6-max-preview | ¥54 | 中等推理 |
| codex5.3 | gpt-5.3-codex | ¥99.68 | 编码 |
| sonnet | claude-sonnet-4-6 | ¥106.8 | 核心推理 |
| opus4.7 | claude-opus-4-7 | ¥178 | 深度决策 |
| gpt5.5 | gpt-5.5 | ¥213.6 | 最强推理 |

## 文件结构

```
token-optimizer/
├── SKILL.md              # 技能定义（主文件）
├── _meta.json            # 元数据
├── package.json          # 包信息
├── README.md             # 说明文档
└── state/
    └── role-config.json  # 角色配置与状态
```

## 版本历史

- **2.1.0** — 极简交互流程 + 卡片样式优化 + 自定义模型支持
- **2.0.0** — 角色预设自动切换 + 文字交互
- **1.0.0** — 初始版本

## 方案文档

完整方案：[按使用人区分的省Token方案](https://www.feishu.cn/docx/RTyFdrJl8oBMQRxb62dcJBJNnYg)
