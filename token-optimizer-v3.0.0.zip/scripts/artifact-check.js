#!/usr/bin/env node
// artifact-check: 验证技能产出的文件格式
const fs = require('fs');
const path = require('path');

const skillRoot = process.argv[2] || path.join(process.cwd(), '.openclaw/workspace/skills/token-optimizer-v3');
let passed = true;

const checks = [
  ['SKILL.md', f => fs.existsSync(path.join(skillRoot, f))],
  ['tests/trigger-cases.jsonl', f => fs.existsSync(path.join(skillRoot, f))],
  ['release-manifest.json', f => {
    const p = path.join(skillRoot, f);
    if (!fs.existsSync(p)) return false;
    const m = JSON.parse(fs.readFileSync(p, 'utf8'));
    return m.name && m.version && m.sha256;
  }],
];

for (const [name, check] of checks) {
  if (check(name)) {
    console.log(`✅ ${name}`);
  } else {
    console.log(`❌ ${name}`);
    passed = false;
  }
}

process.exit(passed ? 0 : 1);
