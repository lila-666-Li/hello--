#!/usr/bin/env node
// admin-collect: 收集管理员审查包
const fs = require('fs');
const path = require('path');

const skillRoot = process.argv[2] || path.join(process.cwd(), '.openclaw/workspace/skills/token-optimizer-v3');
const outDir = path.join(skillRoot, 'admin-review');

if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

// 复制核心文件到审查包
const files = ['SKILL.md', 'release-manifest.json', 'tests/trigger-cases.jsonl'];
for (const f of files) {
  const src = path.join(skillRoot, f);
  if (fs.existsSync(src)) {
    fs.copyFileSync(src, path.join(outDir, f));
  }
}

// 生成审查摘要
const manifest = JSON.parse(fs.readFileSync(path.join(skillRoot, 'release-manifest.json'), 'utf8'));
const summary = {
  skill: manifest.name,
  version: manifest.version,
  sha256: manifest.sha256,
  reviewedAt: new Date().toISOString(),
  status: 'pending_review',
};
fs.writeFileSync(path.join(outDir, 'review-summary.json'), JSON.stringify(summary, null, 2));
console.log(`✅ Admin review bundle collected to: ${outDir}`);
