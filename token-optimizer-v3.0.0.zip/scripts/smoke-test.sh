#!/bin/bash
# smoke: 最小端到端验证 — 检查 SKILL.md 可解析、触发词声明有效
set -e
SKILL_DIR="${1:-.openclaw/workspace/skills/token-optimizer-v3}"
SKILL_FILE="$SKILL_DIR/SKILL.md"

# 检查 frontmatter 存在
if grep -q "^---" "$SKILL_FILE"; then
  echo "✅ frontmatter 存在"
else
  echo "❌ frontmatter 缺失"
  exit 1
fi

# 检查 name 匹配
NAME=$(grep "^name:" "$SKILL_FILE" | head -1 | sed 's/^name: *//')
if [ "$NAME" = "token-optimizer-v3" ]; then
  echo "✅ name 匹配: $NAME"
else
  echo "❌ name 不匹配: $NAME"
  exit 1
fi

# 检查触发词
if grep -q "触发词\|触发边界" "$SKILL_FILE"; then
  echo "✅ 触发边界声明存在"
else
  echo "❌ 触发边界缺失"
  exit 1
fi

# 检查 state 文件
if [ -f "$SKILL_DIR/state/role-config.json" ]; then
  echo "✅ role-config.json 存在"
fi

echo "✅ 冒烟测试通过"
