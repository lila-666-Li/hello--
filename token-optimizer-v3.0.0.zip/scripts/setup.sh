#!/bin/bash
# setup: 安装 token-optimizer-v3 技能到 OpenClaw workspace
set -e
SKILL_DIR="${1:-.openclaw/workspace/skills/token-optimizer-v3}"
echo "Token Optimizer v3.0 - 省钱小达人"
echo "Install target: $SKILL_DIR"
if [ -d "$SKILL_DIR" ]; then
  echo "✅ 技能目录已存在"
else
  echo "❌ 技能目录不存在"
  exit 1
fi
if [ -f "$SKILL_DIR/SKILL.md" ]; then
  echo "✅ SKILL.md 存在"
else
  echo "❌ SKILL.md 缺失"
  exit 1
fi
echo "✅ 安装检查通过"
