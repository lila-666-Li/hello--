#!/usr/bin/env node
// record-run: 记录一次技能运行
const fs = require('fs');
const path = require('path');

const skillRoot = process.argv[2] || path.join(process.cwd(), '.openclaw/workspace/skills/token-optimizer-v3');
const runLog = path.join(skillRoot, 'runs');

if (!fs.existsSync(runLog)) fs.mkdirSync(runLog, { recursive: true });

const record = {
  skill: 'token-optimizer-v3',
  version: '3.0.0',
  timestamp: new Date().toISOString(),
  trigger: process.env.SKILL_TRIGGER || 'unknown',
  role: process.env.SKILL_ROLE || 'unknown',
  status: process.env.SKILL_STATUS || 'completed',
};

const filename = `run-${Date.now()}.json`;
fs.writeFileSync(path.join(runLog, filename), JSON.stringify(record, null, 2));
console.log(`✅ Run recorded: ${filename}`);
