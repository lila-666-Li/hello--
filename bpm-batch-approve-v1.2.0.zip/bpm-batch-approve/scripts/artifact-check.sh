#!/bin/bash
# BPM Batch Approve — Artifact Check
# 验证交付产物完整性

set -e

SKILL_DIR="${1:-$(dirname "$0")/..}"
echo "=== BPM Batch Approve Artifact Check ==="

PASS=true

# Required files
for f in SKILL.md scripts/setup.py scripts/smoke.sh release-manifest.json tests/triggers.jsonl; do
    if [ -f "$SKILL_DIR/$f" ]; then
        echo "✅ $f"
    else
        echo "❌ $f missing"
        PASS=false
    fi
done

# No blocking secrets in SKILL.md
if grep -qiE "(password|token|open_id|chat_id|secret_key)\s*[:=]\s*['\"][a-zA-Z0-9]" "$SKILL_DIR/SKILL.md"; then
    echo "❌ Possible hardcoded credential in SKILL.md"
    PASS=false
else
    echo "✅ No hardcoded credentials"
fi

# No .env or logs
if ls "$SKILL_DIR"/*.env "$SKILL_DIR"/*.log 2>/dev/null; then
    echo "❌ .env or log files found in package"
    PASS=false
else
    echo "✅ No .env or log files"
fi

echo ""
if $PASS; then
    echo "✅ All artifact checks passed!"
    exit 0
else
    echo "❌ Some checks failed"
    exit 1
fi
