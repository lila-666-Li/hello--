#!/bin/bash
# BPM Batch Approve — Export / Admin Collection
# 导出审计记录和管理审查包

set -e

SKILL_DIR="${1:-$(dirname "$0")/..}"
RECORDS_DIR="$SKILL_DIR/_records"
EXPORT_DIR="/tmp/bpm-batch-approve-export-$(date +%Y%m%d_%H%M%S)"

if [ ! -d "$RECORDS_DIR" ] || [ -z "$(ls -A "$RECORDS_DIR")" ]; then
    echo "⚠️ No run records found to export"
    exit 1
fi

mkdir -p "$EXPORT_DIR"
cp -r "$RECORDS_DIR"/* "$EXPORT_DIR/"

# Create summary
echo "=== Export Summary ===" > "$EXPORT_DIR/summary.txt"
echo "Export time: $(date)" >> "$EXPORT_DIR/summary.txt"
echo "Records count: $(ls "$EXPORT_DIR"/*.json 2>/dev/null | wc -l)" >> "$EXPORT_DIR/summary.txt"
echo "Export dir: $EXPORT_DIR" >> "$EXPORT_DIR/summary.txt"

echo "✅ Export completed: $EXPORT_DIR"
