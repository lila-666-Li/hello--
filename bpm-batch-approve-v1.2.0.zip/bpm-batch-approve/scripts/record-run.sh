#!/bin/bash
# BPM Batch Approve — Record Run
# 记录一次审批执行结果到本地审计日志

set -e

SKILL_DIR="${1:-$(dirname "$0")/..}"
RECORDS_DIR="$SKILL_DIR/_records"
mkdir -p "$RECORDS_DIR"

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
RECORD_FILE="$RECORDS_DIR/run_${TIMESTAMP}.json"

# Read run data from stdin (JSON)
cat > "$RECORD_FILE"

echo "✅ Run record saved to $RECORD_FILE"
