#!/usr/bin/env python3
"""
BPM Batch Approve — 依赖安装脚本（方案B：联网下载最新版）
自动检测并安装 bpm-skills 依赖
"""

import os
import sys
import json
import subprocess
import urllib.request

SKILLS_DIR = os.path.expanduser("~/.openclaw/workspace/skills")
BPM_SKILLS_DIR = os.path.join(SKILLS_DIR, "bpm-skills")
GATEWAY_URL = "http://router:3080/api/gateway/twagenthub/agent/skill/download"

REQUIRED_MODULES = ["bpm_auth", "todo_page", "bpm_project_inst"]

def check_bpm_skills():
    """检查 bpm-skills 是否已安装"""
    if not os.path.isdir(BPM_SKILLS_DIR):
        return False, "未找到 bpm-skills 目录"
    
    skilling_path = os.path.join(BPM_SKILLS_DIR, "SKILL.md")
    if not os.path.isfile(skilling_path):
        return False, "bpm-skills 目录存在但缺少 SKILL.md"
    
    missing = []
    for mod in REQUIRED_MODULES:
        mod_dir = os.path.join(BPM_SKILLS_DIR, mod)
        if not os.path.isdir(mod_dir):
            missing.append(mod)
    
    if missing:
        return False, f"缺少子模块: {', '.join(missing)}"
    
    return True, "bpm-skills 已安装且完整"

def install_bpm_skills():
    """从 SkillHub 下载并安装 bpm-skills"""
    print("正在下载 bpm-skills (id:373, v:1.0.4)...")
    
    data = json.dumps({"id": 373, "version": "1.0.4"}).encode("utf-8")
    req = urllib.request.Request(
        GATEWAY_URL,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            zip_data = resp.read()
    except Exception as e:
        print(f"❌ 下载失败: {e}")
        return False
    
    zip_path = "/tmp/bpm-skills-dep.zip"
    with open(zip_path, "wb") as f:
        f.write(zip_data)
    
    print("正在解压安装...")
    os.makedirs(BPM_SKILLS_DIR, exist_ok=True)
    subprocess.run(["unzip", "-o", zip_path, "-d", BPM_SKILLS_DIR], 
                   capture_output=True)
    
    ok, msg = check_bpm_skills()
    if ok:
        print(f"✅ bpm-skills 安装成功！")
        return True
    else:
        print(f"❌ 安装验证失败: {msg}")
        return False

def main():
    print("=" * 50)
    print("🦐 BPM Batch Approve — 依赖检查")
    print("=" * 50)
    
    ok, msg = check_bpm_skills()
    print(f"bpm-skills 状态: {msg}")
    
    if ok:
        print("\n✅ 依赖已满足，无需额外安装。")
        return 0
    
    print("\n⚠️ 需要安装 bpm-skills 依赖")
    print("正在自动安装...\n")
    
    if install_bpm_skills():
        print("\n🎉 全部依赖安装完成！可以开始使用 BPM 批量审批技能了。")
        return 0
    else:
        print("\n💡 手动安装方法：")
        print(f'  curl -sL -X POST "{GATEWAY_URL}" \\')
        print('    -H "Content-Type: application/json" \\')
        print('    -d \'{"id": 373, "version": "1.0.4"}\' \\')
        print(f"    -o /tmp/bpm-skills.zip")
        print(f"  unzip /tmp/bpm-skills.zip -d {BPM_SKILLS_DIR}/")
        return 1

if __name__ == "__main__":
    sys.exit(main())
