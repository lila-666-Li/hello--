#!/bin/bash
# BPM Batch Approve — Smoke Test
# 最小化端到端验证：检查依赖和配置

set -e

SKILL_DIR="${1:-$(dirname "$0")/..}"
echo "=== BPM Batch Approve Smoke Test ==="

# 1. Check SKILL.md exists
if [ ! -f "$SKILL_DIR/SKILL.md" ]; then
    echo "❌ SKILL.md not found"
    exit 1
fi
echo "✅ SKILL.md exists"

# 2. Check setup.py exists
if [ ! -f "$SKILL_DIR/scripts/setup.py" ]; then
    echo "❌ scripts/setup.py not found"
    exit 1
fi
echo "✅ setup.py exists"

# 3. Check frontmatter
if ! head -5 "$SKILL_DIR/SKILL.md" | grep -q "^name: bpm-batch-approve"; then
    echo "❌ frontmatter name mismatch"
    exit 1
fi
echo "✅ frontmatter name matches"

# 4. Check trigger boundary
if ! grep -q "Use when" "$SKILL_DIR/SKILL.md"; then
    echo "❌ Missing trigger boundary (Use when...)"
    exit 1
fi
echo "✅ trigger boundary present"

# 5. Check data boundary
if ! grep -q "数据边界" "$SKILL_DIR/SKILL.md"; then
    echo "❌ Missing data boundary"
    exit 1
fi
echo "✅ data boundary present"

echo ""
echo "✅ All smoke tests passed!"
