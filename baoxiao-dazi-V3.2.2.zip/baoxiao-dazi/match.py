#!/usr/bin/env python3
"""
报销搭子 - 智能匹配脚本 v3.0
数据源：会计科目映射表即BPM报销科目-费用说明对应项（2026-04）
特性：
  1. 费用说明直接使用官方数据
  2. 排除词机制（开会≠差旅）
  3. 城市范围区分（出本市→差旅费）
  4. 歧义词三轮追问
  5. 非业务款识别（引导找李璐瑶）
  6. 英文无意义输入过滤
用法：
  python3 match.py "我买了键盘和鼠标"
  python3 match.py --interactive
"""
import json, sys, os, re, argparse

DATA_FILE = os.path.join(os.path.dirname(__file__), 'expense-categories.json')
VERSION = "v3.0"

# ===== 场景预设 =====
SCENARIOS = {
    "出差": ["出差", "异地", "外地"],
    "加班": ["加班", "晚上", "深夜", "延时"],
    "请客": ["请客", "招待", "宴请"],
    "游戏": ["游戏", "玩家", "投放", "素材", "推广"],
    "办公": ["办公", "文具", "日用品", "办公用品"],
    "邮寄": ["顺丰", "快递", "寄", "EMS", "邮寄", "中通", "圆通", "韵达", "速递"],
    "节日": ["中秋", "月饼", "端午", "粽子", "春节", "年货", "节日", "福利品"],
    "展会": ["展会", "参展", "行业展会", "展会门票"],
}

# ===== 出本市判定 =====
OUT_OF_CITY = [
    "出差", "异地", "外地", "去上海", "去北京", "去广州", "去深圳", "去成都",
    "去杭州", "去南京", "去武汉", "去重庆", "去西安", "去长沙", "去郑州", "去济南",
    "去青岛", "去厦门", "去昆明", "去贵阳", "去兰州", "去太原", "去石家庄", "去天津",
    "去海南", "去三亚", "去海口", "飞", "航班", "机票", "高铁票", "火车票", "动车",
    "高铁", "火车", "跨市", "跨省", "长途",
]
TRANSPORT_KW = ["打车", "滴滴", "网约车", "出租车", "车费", "交通", "地铁", "公交", "的士"]

# ===== 付款类型判断 =====
PAYMENT_KEYWORDS = {
    "非业务款": ["合约", "合同", "供应商", "采购合同", "服务协议", "合作协议", "框架协议",
                 "采购订单", "订单", "报价单", "请款", "预付款", "尾款", "分期", "验收"],
    "费用报销": ["报销", "垫付", "垫钱", "自费", "我付的", "我买的", "打车", "吃饭",
                  "住宿", "酒店", "机票", "高铁", "快递", "外卖", "日用品", "文具"],
}

# ===== 歧义词清单 =====
AMBIGUOUS = {
    "笔记本": ("请问是指哪种笔记本？", ["A. 纸质笔记本/文具", "B. 电脑/电子设备"]),
    "会员": ("请问是什么类型的会员？", ["A. 软件会员（WPS/Adobe等）", "B. 协会/社团会员", "C. 招聘网站会员"]),
    "聚餐": ("请问聚餐的场景是？", ["A. 部门团建", "B. 请客户吃饭", "C. 加班聚餐"]),
    "送礼": ("请问礼品是给谁的？", ["A. 客户/合作方", "B. 员工内部"]),
    "送人": ("请问这个物品是给谁的？", ["A. 客户/合作方", "B. 员工内部"]),
    "保险": ("请问是什么保险？", ["A. 员工保险", "B. 公司财产/业务保险"]),
}

# ===== 排除词 =====
EXCLUDE = {
    "开会": ["差旅费/住宿费"],
    "会议": ["差旅费/住宿费"],
    "生日": ["会议费"],
    "聚餐": ["差旅费"],
    "去公司": ["员工福利_活动费"],
    "通勤": ["员工福利_活动费"],
}

# ===== 关键词指引 =====
INVOICE_URL = "https://lx3qcyzne8.feishu.cn/base/COcMb4UiDaugJBs5CqocnKaanmh?table=tbllN6TSrefLEj9a&view=vewuxh5NZ6"
KEYWORD_GUIDE = {
    # 开票信息（丰富关键词）
    "开票信息": f"🧾 开票资料：{INVOICE_URL}",
    "开票资料": f"🧾 开票资料：{INVOICE_URL}",
    "发票信息": f"🧾 开票资料：{INVOICE_URL}",
    "开发票": f"🧾 开票资料：{INVOICE_URL}",
    "公司开票": f"🧾 开票资料：{INVOICE_URL}",
    "税号": f"🧾 开票资料：{INVOICE_URL}",
    "发票抬头": f"🧾 开票资料：{INVOICE_URL}",
    "开票": f"🧾 开票资料：{INVOICE_URL}",
    "纳税人资质": f"🧾 开票资料：{INVOICE_URL}",
    "增值税发票": f"🧾 开票资料：{INVOICE_URL}",
    "专票": f"🧾 开票资料：{INVOICE_URL}",
    "普票": f"🧾 开票资料：{INVOICE_URL}",
    # 报销科目引导（丰富关键词）
    "报销科目": "💡 直接告诉我你买了什么/做了什么就行 😊",
    "报什么科目": "💡 直接告诉我你买了什么/做了什么就行 😊",
    "费用科目": "💡 直接告诉我你买了什么/做了什么就行 😊",
    "怎么报": "💡 直接告诉我你买了什么/做了什么就行 😊",
    "报销流程": "💡 直接告诉我你买了什么/做了什么就行 😊",
    "报销指南": "💡 直接告诉我你买了什么/做了什么就行 😊",
    # 附件清单（丰富关键词）
    "附件清单": "📎 付款申请：盖章版合约+请款单/报价单/验收单｜差旅费：出差申请单+付款截图｜交通费：外勤申请单+付款截图",
    "报销附件": "📎 付款申请：盖章版合约+请款单/报价单/验收单｜差旅费：出差申请单+付款截图｜交通费：外勤申请单+付款截图",
    "需要什么附件": "📎 付款申请：盖章版合约+请款单/报价单/验收单｜差旅费：出差申请单+付款截图｜交通费：外勤申请单+付款截图",
    "附件要求": "📎 付款申请：盖章版合约+请款单/报价单/验收单｜差旅费：出差申请单+付款截图｜交通费：外勤申请单+付款截图",
    "报销材料": "📎 付款申请：盖章版合约+请款单/报价单/验收单｜差旅费：出差申请单+付款截图｜交通费：外勤申请单+付款截图",
    "报销凭证": "📎 付款申请：盖章版合约+请款单/报价单/验收单｜差旅费：出差申请单+付款截图｜交通费：外勤申请单+付款截图",
    "报销单据": "📎 付款申请：盖章版合约+请款单/报价单/验收单｜差旅费：出差申请单+付款截图｜交通费：外勤申请单+付款截图",
}


# ===== 核心函数 =====
def load_data():
    with open(DATA_FILE, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return [item for item in data
            if '【禁用状态】' not in item.get('keywords', '')
            and '【禁用】' not in item.get('category', '')]

def tokenize(text):
    words = re.findall(r'[\u4e00-\u9fff]{2,10}|[a-zA-Z]+', text)
    tokens = set()
    # 停用词（无意义高频词）
    stop_words = {'时候', '的话', '怎么', '如何', '什么', '这个', '那个', '一个', '一些', '一下', '一下'}
    for w in words:
        if w in stop_words:
            continue
        tokens.add(w)
        for i in range(len(w)-1):
            bigram = w[i:i+2]
            if bigram not in stop_words:
                tokens.add(bigram)
        if len(w) >= 4:
            for i in range(len(w)-2):
                trigram = w[i:i+3]
                if trigram not in stop_words:
                    tokens.add(trigram)
    return tokens

def match(query, data, top_k=3):
    query_tokens = tokenize(query)
    query_lower = query.lower()
    if not query_tokens:
        return []

    # 场景预判
    scenario_hints = set()
    for scene_kw in SCENARIOS.values():
        for kw in scene_kw:
            if kw in query_lower:
                scenario_hints.update(scene_kw)

    # 排除词
    exclude = set()
    for trigger, targets in EXCLUDE.items():
        if trigger in query_lower:
            exclude.update(targets)

    # 城市范围区分
    is_transport = any(kw in query_lower for kw in TRANSPORT_KW)
    is_out = any(kw in query_lower for kw in OUT_OF_CITY)
    is_local_transport = is_transport and not is_out  # 纯市内交通
    if is_transport:
        if is_out:
            exclude.add('市内交通费')
        else:
            exclude.add('差旅费/打车费')

    scores = []
    for item in data:
        if item['description'] in exclude or item['category'] in exclude:
            continue
        score = 0
        desc_lower = item['description'].lower()
        kw_lower = item['keywords'].lower()
        cat_lower = item['category'].lower()
        searchable = f"{cat_lower} {desc_lower} {kw_lower}"

        # 全句精确匹配
        if query_lower in desc_lower or query_lower in kw_lower:
            score += 50

        # Token 级匹配
        for token in query_tokens:
            if token in desc_lower:
                score += 30
            elif token in kw_lower:
                score += 15
            elif token in cat_lower:
                score += 8
            elif token in searchable:
                score += 3

        # 场景加成
        for hint in scenario_hints:
            if hint in searchable:
                score += 12

        # 市内交通场景加成（地铁/公交/去公司等）
        if is_local_transport and item['category'] == '市内交通费':
            score += 30

        # 双字词加成
        for bg in (t for t in query_tokens if len(t) == 2):
            if bg in desc_lower:
                score += 20
            elif bg in kw_lower:
                score += 12

        if score > 0:
            scores.append((score, item))

    scores.sort(key=lambda x: (-x[0], x[1]['category']))
    return scores[:top_k]

def format_result(results, query=""):
    if not results:
        return (
            f"❌ 未找到「{query}」匹配的报销科目\n\n"
            "💡 试试这样说：\n"
            "  • 「出差的XX费用」→ 差旅费\n"
            "  • 「办公室的XX」→ 办公用品/办公费\n"
            "  • 「请客户XX」→ 招待费\n"
            "  • 「玩家/游戏相关」→ 业务宣传费\n"
            "  • 「加班XX」→ 员工福利/市内交通费\n\n⚠️ 以上建议仅供参考，最终解释权归财务部 🦐✨"
        )
    lines = [f"🦐 **报销建议**｜{query} 💰"]
    lines.append("")
    for i, (score, item) in enumerate(results):
        if i == 0:
            lines.append(f"🏷️ **推荐科目**：{item['category']}")
            lines.append(f"📝 **费用说明**：{item['description']}")
            
            cat = item['category']
            if '差旅费' in cat:
                lines.append(f"📎 **附件提醒**：📄 出差申请单 + 💳 付款截图")
            elif '交通费' in cat:
                lines.append(f"📎 **附件提醒**：📄 外勤申请单 + 💳 付款截图")
            elif '招待费' in cat:
                lines.append(f"📎 **附件提醒**：💳 付款截图 + 📋 招待事由说明")
            else:
                lines.append(f"📎 **附件提醒**：💳 付款截图")
        else:
            lines.append(f"💭 备选：{item['category']} / {item['description']}")
    
    lines.append("")
    lines.append(f"⚠️ 以上建议仅供参考，最终解释权归财务部 🦐✨")
    return "\n".join(lines)


# ===== 追问机制 =====
def detect_payment_type(q):
    r = sum(1 for k in PAYMENT_KEYWORDS["费用报销"] if k in q)
    n = sum(1 for k in PAYMENT_KEYWORDS["非业务款"] if k in q)
    if n > r: return "非业务款"
    if r > n: return "费用报销"
    return None

def format_round1(query, hint):
    if hint == "非业务款":
        return (
            f"📋 这笔费用看起来像是非业务款付款申请（涉及合约/供应商/采购等）\n\n"
            f"💡 非业务款付款申请需要走付款申请流程，建议联系 李璐瑶 处理 😊\n\n"
            f"如果确认是费用报销，请回复「报销」继续查询\n\n⚠️ 以上建议仅供参考，最终解释权归财务部 🦐✨"
        )
    return (
        f"🤔 关于「{query}」，我需要先确认几个信息：\n\n"
        f"第一步：这笔费用属于哪种情况？\n"
        f"  A. 我已经付钱/垫付了，需要报销\n"
        f"  B. 还没付款，需要申请公对公付款（非业务款）\n\n"
        f"直接回复 A 或 B 就行 😊\n\n⚠️ 以上建议仅供参考，最终解释权归财务部 🦐✨"
    )

def format_round2(payment_type, amb_info):
    if payment_type == "B":
        return (
            "📋 公对公付款（非业务款）需要走付款申请流程\n\n"
            "💡 建议联系 李璐瑶 处理，需要准备：\n"
            "  • 盖章版合约\n  • 请款单/报价单/验收单\n\n⚠️ 以上建议仅供参考，最终解释权归财务部 🦐✨"
        )
    if amb_info:
        return f"📋 {amb_info[0]}\n" + "\n".join(f"  {o}" for o in amb_info[1]) + "\n\n直接回复选项字母 😊\n\n⚠️ 以上建议仅供参考，最终解释权归财务部 🦐✨"
    return (
        "📋 请问这笔费用是在什么场景下产生的？\n"
        "  A. 出差期间\n  B. 日常办公\n  C. 招待客户\n  D. 加班相关\n  E. 员工福利\n\n⚠️ 以上建议仅供参考，最终解释权归财务部 🦐✨"
    )

def format_round3(pt):
    target = "李璐瑶" if pt in ["B", "非业务款"] else "您的分管财务同事"
    return f"📋 这个费用场景比较特殊，建议联系 {target} 确认报销科目，以免退单 😊\n\n⚠️ 以上建议仅供参考，最终解释权归财务部 🦐✨"


# ===== 主程序 =====
def main():
    parser = argparse.ArgumentParser(description='请款报销管家')
    parser.add_argument('query', nargs='?', help='费用描述')
    parser.add_argument('--top', type=int, default=3)
    parser.add_argument('--interactive', action='store_true')
    args = parser.parse_args()

    if not args.query and not args.interactive:
        print(f"🦐 报销搭子 {VERSION} - 智能匹配报销科目\n\n"
              f"用法：\n  python3 match.py \"我买了键盘\"\n  python3 match.py \"出差打车\"\n\n"
              f"💡 直接告诉我你买了什么/做了什么，我来帮你找科目 😊\n"
              f"交互模式：python3 match.py --interactive")
        sys.exit(0)

    query = args.query.strip() if args.query else ""

    # 英文过滤
    if query and re.match(r'^[a-zA-Z]{4,}$', query):
        print(f"❌ 未找到「{query}」匹配的报销科目\n\n"
              "💡 请用中文描述费用场景，例如：\n"
              '  • 「出差的XX费用」→ 差旅费\n  • 「办公室的XX」→ 办公用品\n  • 「请客户XX」→ 招待费')
        sys.exit(0)

    data = load_data()

    if args.interactive:
        print(f"🦐 报销搭子 {VERSION} - 交互模式")
        print("输入费用描述，按回车查询。输入 q 退出。\n")
        state = {"round": 0, "payment_type": None, "amb_info": None, "query": ""}
        while True:
            try:
                q = input("💬 > ").strip()
                if q.lower() in ('q', 'quit', 'exit', '退出'):
                    print("👋 再见！"); break
                if not q: continue

                if state["round"] > 0:
                    answer = q.upper().strip()
                    if state["round"] == 1:
                        if answer in ("A", "报销"):
                            state["payment_type"] = "费用报销"
                            for word, info in AMBIGUOUS.items():
                                if word in state["query"].lower():
                                    state["amb_info"] = info; break
                            state["round"] = 2
                            print(format_round2("费用报销", state.get("amb_info")))
                        elif answer in ("B", "非业务款", "付款"):
                            print("📋 公对公付款（非业务款）需要走付款申请流程\n\n"
                                  "💡 建议联系 李璐瑶 处理，需要准备：\n  • 盖章版合约\n  • 请款单/报价单/验收单\n\n⚠️ 以上建议仅供参考，最终解释权归财务部 🦐✨")
                            state["round"] = 0
                        else: print("请回复 A 或 B 😊")
                        print(); continue
                    elif state["round"] == 2:
                        amb = state.get("amb_info")
                        matched = False
                        if amb:
                            for i, opt in enumerate(amb[1]):
                                if answer == chr(ord('A') + i):
                                    results = match(state["query"], data, args.top)
                                    if results: print(format_result(results, state["query"]))
                                    else: print(format_round3(state["payment_type"]))
                                    matched = True; break
                        if not matched: print(format_round3(state["payment_type"]))
                        state["round"] = 0; print(); continue

                # 关键词指引
                for kw, resp in KEYWORD_GUIDE.items():
                    if kw in q: print(resp); print(); break
                else:
                    hint = detect_payment_type(q.lower())
                    amb = None
                    for word, info in AMBIGUOUS.items():
                        if word in q.lower(): amb = info; break
                    if hint == "非业务款" or amb:
                        state = {"round": 1, "payment_type": None, "amb_info": amb, "query": q}
                        print(format_round1(q, hint))
                    else:
                        results = match(q, data, args.top)
                        print(format_result(results, q))
                    print()
            except (EOFError, KeyboardInterrupt):
                print("\n👋 再见！"); break
    else:
        for kw, resp in KEYWORD_GUIDE.items():
            if kw in query: print(resp); sys.exit(0)

        hint = detect_payment_type(query.lower())
        amb = None
        for word, info in AMBIGUOUS.items():
            if word in query.lower(): amb = info; break
        if hint == "非业务款":
            print(format_round1(query, hint))
        elif amb:
            print(format_round1(query, hint))
            print(f"\n（命令行模式：建议使用 python3 match.py --interactive 进行多轮确认）")
        else:
            results = match(query, data, args.top)
            print(format_result(results, query))

if __name__ == '__main__':
    main()
