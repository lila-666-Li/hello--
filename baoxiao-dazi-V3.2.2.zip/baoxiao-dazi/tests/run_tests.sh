#!/bin/bash
# 报销搭子 - 回归测试脚本
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$(dirname "$SCRIPT_DIR")"
PASS=0
FAIL=0
TOTAL=0

echo "baoxiao-dazi v3.2.2 regression tests"
echo "====================================="

# Check files
for f in SKILL.md match.py expense-categories.json expense-descriptions.json VERSION; do
    if [ -f "$SKILL_DIR/$f" ]; then
        echo "PASS: $f exists"
        PASS=$((PASS+1))
    else
        echo "FAIL: $f missing"
        FAIL=$((FAIL+1))
    fi
    TOTAL=$((TOTAL+1))
done

# Check Use when trigger
if grep -q "Use when" "$SKILL_DIR/SKILL.md"; then
    echo "PASS: SKILL.md has Use when trigger"
    PASS=$((PASS+1))
else
    echo "FAIL: SKILL.md missing Use when"
    FAIL=$((FAIL+1))
fi
TOTAL=$((TOTAL+1))

# Check test cases
if [ -f "$SCRIPT_DIR/match-test-cases.json" ]; then
    echo "PASS: test cases file exists"
    PASS=$((PASS+1))
else
    echo "FAIL: missing test cases"
    FAIL=$((FAIL+1))
fi
TOTAL=$((TOTAL+1))

# Check disclaimer
if grep -q "解释权归财务部" "$SKILL_DIR/match.py"; then
    echo "PASS: disclaimer present"
    PASS=$((PASS+1))
else
    echo "FAIL: disclaimer missing"
    FAIL=$((FAIL+1))
fi
TOTAL=$((TOTAL+1))

# Check release manifest
if [ -f "$SKILL_DIR/release-manifest.json" ]; then
    echo "PASS: release-manifest.json exists"
    PASS=$((PASS+1))
else
    echo "FAIL: release-manifest.json missing"
    FAIL=$((FAIL+1))
fi
TOTAL=$((TOTAL+1))

echo ""
echo "Quick match tests:"
python3 "$SKILL_DIR/match.py" "出差打车" 2>&1 | grep -q "差旅费"
if [ $? -eq 0 ]; then echo "PASS: chuchai ->差旅费"; PASS=$((PASS+1)); else echo "FAIL: chuchai"; FAIL=$((FAIL+1)); fi
TOTAL=$((TOTAL+1))

python3 "$SKILL_DIR/match.py" "请客户吃饭" 2>&1 | grep -q "招待费"
if [ $? -eq 0 ]; then echo "PASS: qingke -> 招待费"; PASS=$((PASS+1)); else echo "FAIL: qingke"; FAIL=$((FAIL+1)); fi
TOTAL=$((TOTAL+1))

python3 "$SKILL_DIR/match.py" "买了键盘" 2>&1 | grep -q "办公用品"
if [ $? -eq 0 ]; then echo "PASS: jianpan -> 办公用品"; PASS=$((PASS+1)); else echo "FAIL: jianpan"; FAIL=$((FAIL+1)); fi
TOTAL=$((TOTAL+1))

python3 "$SKILL_DIR/match.py" "WPS软件服务费" 2>&1 | grep -q "软件服务费"
if [ $? -eq 0 ]; then echo "PASS: WPS软件服务费 -> 软件服务费"; PASS=$((PASS+1)); else echo "FAIL: WPS软件服务费"; FAIL=$((FAIL+1)); fi
TOTAL=$((TOTAL+1))

# Test ambiguous word detection (会员 triggers follow-up)
python3 "$SKILL_DIR/match.py" "软件会员" 2>&1 | grep -q "确认"
if [ $? -eq 0 ]; then echo "PASS: 会员 triggers follow-up (歧义追问)"; PASS=$((PASS+1)); else echo "FAIL: 会员 follow-up"; FAIL=$((FAIL+1)); fi
TOTAL=$((TOTAL+1))

echo ""
echo "====================================="
echo "Results: $PASS/$TOTAL passed, $FAIL failed"
if [ $FAIL -eq 0 ]; then echo "ALL PASSED!"; else echo "WARN: $FAIL items need fixing"; fi
