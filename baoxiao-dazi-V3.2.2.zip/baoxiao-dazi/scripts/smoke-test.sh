#!/bin/bash
# Smoke test for 报销搭子
# Quick check that core functionality works

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$(dirname "$SCRIPT_DIR")"

echo "🦐 Running smoke tests..."

# Test 1: Basic match
python3 "$SKILL_DIR/match.py" "出差打车" > /dev/null 2>&1
if [ $? -ne 0 ]; then echo "❌ Failed: 出差打车"; exit 1; fi

# Test 2: Entertainment expense
python3 "$SKILL_DIR/match.py" "请客户吃饭" > /dev/null 2>&1
if [ $? -ne 0 ]; then echo "❌ Failed: 请客户吃饭"; exit 1; fi

# Test 3: Office supplies
python3 "$SKILL_DIR/match.py" "买了键盘" > /dev/null 2>&1
if [ $? -ne 0 ]; then echo "❌ Failed: 买了键盘"; exit 1; fi

# Test 4: Software
python3 "$SKILL_DIR/match.py" "软件会员" > /dev/null 2>&1
if [ $? -ne 0 ]; then echo "❌ Failed: 软件会员"; exit 1; fi

echo "✅ All smoke tests passed!"
exit 0
