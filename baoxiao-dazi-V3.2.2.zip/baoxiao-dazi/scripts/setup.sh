#!/bin/bash
# Setup script for 报销搭子
# Verify installation and dependencies

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$(dirname "$SCRIPT_DIR")"

echo "🦐 报销搭子 setup..."

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 not found"
    exit 1
fi

# Check required files
for f in SKILL.md match.py expense-categories.json expense-descriptions.json VERSION; do
    if [ ! -f "$SKILL_DIR/$f" ]; then
        echo "❌ Missing: $f"
        exit 1
    fi
done

echo "✅ All dependencies verified"

# Run smoke tests
bash "$SCRIPT_DIR/smoke-test.sh"
exit $?
